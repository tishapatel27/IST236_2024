import React from 'react';
import myPhoto from '../src/docs/IMG_7389.jpg'; 

const ImageSection = () => {
  return (
    <div>
      <img src={myPhoto} alt="Tisha Patel" />
    </div>
  );
};

export default ImageSection;
